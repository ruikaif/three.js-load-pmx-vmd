On My Own By Milany
----------------------------------
On My Own(Short Ver.)
I will make the long ver.
And in fact I have not finished it.
But maybe I won't put it for DL.
Cuz...I don't know XD
Have fun!!!
*^^*
----------------------------------
Always Credit.

Don't claim it to yours.

You can edit the camera befittingly(Like your model is too tall or too  short.).

Don't edit the motion(You can edit it if the motion and model are not suitable).
[��:��ģ�����Ƶ�����£�����Ա༭����]

Don't take parts from them.

Don't try to make the longer vision.

If someone breaks my rule,I'll remove the download.

Have Fun!!!
